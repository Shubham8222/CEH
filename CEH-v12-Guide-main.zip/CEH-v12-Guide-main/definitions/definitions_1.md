# Definitions 1

## 801.1x
EEE 802.1X is an IEEE Standard for port-based Network Access Control (PNAC).
It is part of the IEEE 802.1 group of networking protocols.
It provides an authentication mechanism to devices wishing to attach to a LAN or WLAN.

Links
- [https://en.wikipedia.org/wiki/IEEE_802.1X](https://en.wikipedia.org/wiki/IEEE_802.1X)
