# Definitions Q

## Qualys
Qualys VMDR 2.0 enables customers to automatically detect vulnerabilities and critical misconfigurations per CIS benchmarks, broken out by asset.

Links
- [https://www.qualys.com/apps/vulnerability-management-detection-response](https://www.qualys.com/apps/vulnerability-management-detection-response)
