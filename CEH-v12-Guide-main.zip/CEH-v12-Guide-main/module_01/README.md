# Module 01: Introduction to Ethical Hacking

## About

According to the official C|EH brochure this module covers the following material.

> Cover the fundamentals of key issues in the information security world,
including the basics of ethical hacking, information security controls,
relevant laws, and standard procedures.
