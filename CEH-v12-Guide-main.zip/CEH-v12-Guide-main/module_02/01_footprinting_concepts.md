# Section 01: Footprinting Concepts

## Footprinting
Footprinting

[Definition](../definitions/definitions_F.md#footprinting)
