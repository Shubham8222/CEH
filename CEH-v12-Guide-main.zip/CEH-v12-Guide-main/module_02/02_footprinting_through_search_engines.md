# Section 02: Footprinting through Search Engines

## Google Hacking
Google hacking

[definition](../definitions/definitions_g.md#google-hacking)

## Google Hacking Database (GHDB)
Google Hacking Database (GHDB)

[Definition](../definitions/definitions_G.md#google-hacking-database)

## Metasearch Engine
Metasearch engine

[Definition](../definitions/definitions_M.md#metasearch-engine)
