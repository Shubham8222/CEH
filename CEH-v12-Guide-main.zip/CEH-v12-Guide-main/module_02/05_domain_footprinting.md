# Section 05: Domain Footprinting

## Whois Footprinting
Whois

[Definition](../definitions/definitions_W.md#whois)

## DNS Footprinting
Domain name system (DNS)

[Definition](../definitions/definitions_D.md#domain-name-system)

Dig

[Definition](../definitions/definitions_D.md#dig)

Nslookup

[Definition](../definitions/definitions_N.md#nslookup)

Reverse DNS lookup, dnsrecon

[Definition](../definitions/definitions_D.md#dnsrecon)
