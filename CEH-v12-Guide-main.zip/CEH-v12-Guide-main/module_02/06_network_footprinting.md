# Section 06: Network Footprinting

## Traceroute
Traceroute

[Definition](../definitions/definitions_T.md#traceroute)
