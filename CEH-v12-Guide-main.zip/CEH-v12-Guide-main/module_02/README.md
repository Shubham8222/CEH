# Module 02: Foot Printing and Reconnaissance

## About

According to the official C|EH brochure this module covers the following material.

> Learn how to use the latest techniques and tools to perform foot
printing and reconnaissance, a critical pre-attack phase of the ethical
hacking process.
 