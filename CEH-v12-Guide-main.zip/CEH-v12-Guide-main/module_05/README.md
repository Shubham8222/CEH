# Module 05: Vulnerability Analysis

## About

According to the official C|EH brochure this module covers the following material.

> Learn how to identify security loopholes in a target organization’s
network, communication infrastructure, and end systems. Different
types of vulnerability assessment and vulnerability assessment tools.
