# Section 01: Gaining Access

## Gaining access
Password cracking

[Definition](../definitions/definitions_P.md#password-cracking)

Security account manager (SAM) database

[Definition](../definitions/definitions_S.md#security-account-manager-database)

Net technology lan manager (NTLM)

[Definition](../definitions/definitions_N.md#net-technology-lan-manager)

Kerberos

[Definition](../definitions/definitions_K.md#kerberos)

Dictionary Attack

[Definition](../definitions/definitions_D.md#dictionary-attack)

Brute force attack

[Definition](../definitions/definitions_B.md#brute-force-attack)

Password spraying attack

[Definition](../definitions/definitions_P.md#password-spraying-attack)

Hashcat

[Definition](../definitions/definitions_H.md#hashcat)

Trojan horse

[Definition](../definitions/definitions_T.md#trojan-horse)

Man in the middle attack (MiTM)

[Definition](../definitions/definitions_M.md#man-in-the-middle-attack)

Rainbow table
 
[Definition](../definitions/definitions_R.md#rainbow-table)

John the ripper

[Definition](../definitions/definitions_J.md#john-the-ripper)

Password salt

[Definitions](../definitions/definitions_S.md#salt)

## Exploitation
Exploit DB

[Definition](../definitions/definitions_E.md#exploit-db)

VulDB

[Definition](../definitions/definitions_V.md#vuldb)

Buffer overflow

[Defintion](../definitions/definitions_B.md#buffer-overflow)

Return oriented programming
 
[Definition](../definitions/definitions_E.md#exploit-db)
