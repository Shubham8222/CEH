# Module 06: System Hacking

## About

According to the official C|EH brochure this module covers the following material.

> Learn about the various system hacking methodologies—including steganography, steganalysis attacks, and covering tracks—used to discover
system and network vulnerabilities.
