# Section 04: Virus and Worms Concepts

## Viruses and Worms
Virus

[Definition](../definitions/definitions_V.md#virus)

Logic bomb

[Definition](../definitions/definitions_L.md#logic-bomb)

Virus hoax
 
[Definition](../definitions/definitions_V.md#virus-hoax)

Worm

[Definition](../definitions/definitions_W.md#worm)
