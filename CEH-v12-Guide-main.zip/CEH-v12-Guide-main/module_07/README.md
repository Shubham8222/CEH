# Module 07: Malware Threats

## About

According to the official C|EH brochure this module covers the following material.

> Learn different types of malware (Trojan, virus, worms, etc.), APT
and fileless malware, malware analysis procedure, and malware
countermeasures.
