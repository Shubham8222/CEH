# Section 04: ARP poisoning

## ARP poisoning
Address resolution protocol (ARP)

[Definition](../definitions/definitions_A.md#address-resolution-protocol)

Address resolution protocol (ARP) spoofing

[Definition](../definitions/definitions_A.md#address-resolution-protocol-spoofing)
