# Section 05: ARP poisoning

## Spoofing
Media Access Control (MAC) spoofing

[Definition](../definitions/definitions_M.md#media-access-control-address-spoofing)

VLAN hopping

[Definition](../definitions/definitions_V.md#vlan-hopping)

Spanning tree protocol (STP)

[Definition](../definitions/definitions_S.md#spanning-tree-protocol)
