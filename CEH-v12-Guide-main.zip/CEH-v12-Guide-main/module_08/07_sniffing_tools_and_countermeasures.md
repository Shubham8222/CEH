# Section 07: Sniffing Tools and Countermeasures

## Sniffing Tools
Wireshark

[Definition](../definitions/definitions_W.md#wireshark)


## Countermeasures
- Restrict physical access to all hardware.
- Use encryption for all protocols and services.
- Implement MAC filtering.
- Segment your networks.

nmap

[Definition](../definitions/definitions_N.md#nmap)
