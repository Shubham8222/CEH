# Section 03: Insider Threats

## Insider Threats

[Definition](../definitions/definitions_I.md#insider-threat)
