# Section 04: Identity Theft

## Identity Theft
Social security number (SSN)

[Definition](../definitions/definitions_S.md#social-security-number)

Identity theft

[Definition](../definitions/definitions_I.md#identity-theft)
