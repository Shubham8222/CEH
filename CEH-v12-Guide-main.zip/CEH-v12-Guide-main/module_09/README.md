# Module 09: Social Engineering

## About

According to the official C|EH brochure this module covers the following material.

> Learn social engineering concepts and techniques, including how to
identify theft attempts, audit human-level vulnerabilities, and suggest
social engineering countermeasures.
