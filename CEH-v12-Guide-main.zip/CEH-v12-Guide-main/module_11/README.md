# Module 11: Session Hijacking

## About

According to the official C|EH brochure this module covers the following material.

> Understand the various session hijacking techniques used to discover
network-level session management, authentication, authorization, and
cryptographic weaknesses and associated countermeasures.
