# Section 03: Evading Firewalls

## Evading Firewalls
Firewalking

[Definition](../definitions/definitions_F.md#firewalking)

Branner grabbing

[Definition](../definitions/definitions_B.md#banner-grabbing)

Anonymous surfing

[Definition](../definitions/definitions_A.md#anonymous-surfing)

Proxy server

[Definition](../definitions/definitions_P.md#proxy-server)

Tunneling

[Definition](../definitions/definitions_T.md#tunneling)
