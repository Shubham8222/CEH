# Module 12: Evading IDS, Firewalls, and Honeypots

## About

According to the official C|EH brochure this module covers the following material.

> Get introduced to firewall, intrusion detection system (IDS), and
honeypot evasion techniques; the tools used to audit a network
perimeter for weaknesses; and countermeasures.
