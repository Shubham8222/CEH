# TryHackMe

Links
- [https://tryhackme.com/room/redteamnetsec](https://tryhackme.com/room/redteamnetsec)
- [https://tryhackme.com/room/redteamfirewalls](https://tryhackme.com/room/redteamfirewalls)
- [https://tryhackme.com/room/avevasionshellcode](https://tryhackme.com/room/avevasionshellcode)
- [https://tryhackme.com/room/signatureevasion](https://tryhackme.com/room/signatureevasion)
- [https://tryhackme.com/room/runtimedetectionevasion](https://tryhackme.com/room/runtimedetectionevasion)
- [https://tryhackme.com/room/livingofftheland](https://tryhackme.com/room/livingofftheland)
