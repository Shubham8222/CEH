# Section 03: Web Applications Hacking Methodology

## Hacking Methodology
Whois

[Definition](../definitions/definitions_W.md#whois)

Footprinting

[Definition](../definitions/definitions_F.md#footprinting)

nmap

[Definition](../definitions/definitions_N.md#nmap)

netcat

[Definition](../definitions/definitions_N.md#netcat)

Web crawler

[Definition](../definitions/definitions_W.md#web-spider)

OWASP ZAP

[Definition](../definitions/definitions_O.md#owasp-zap)

Burp suite

[Definition](../definitions/definitions_B.md#burp-suite)

Dig

[Definition](../definitions/definitions_D.md#dig)

Gobuster

[Definition](../definitions/definitions_G.md#gobuster)

Improper input validation

[Definition](../definitions/definitions_I.md#improper-input-validation)

Brute force attack

[Definition](../definitions/definitions_B.md#brute-force-attack)

Hydra

[Definition](../definitions/definitions_H.md#hydra)

Database connection

[Definition](../definitions/definitions_D.md#database-connection)

Metasploit

[Definition](../definitions/definitions_M.md#metasploit)
