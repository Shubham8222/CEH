# Module 14: Hacking Web Applications

## About

According to the official C|EH brochure this module covers the following material.

> Learn about web application attacks, including a comprehensive web
application hacking methodology used to audit vulnerabilities in web
applications and countermeasures.
 