# Section 02: Types of SQL Injection

## Types
