# Section 03: Wireless Threats

## Wireless Threats
Wardriving

[Definition](../definitions/definitions_W.md#wardriving)

Rogue access point

[Definition](../definitions/definitions_R.md#rogue-access-point)

MAC spoofing

[Definition](../definitions/definitions_M.md#media-access-control-address-spoofing)

Eavesdropping

[Definition](../definitions/definitions_E.md#eavesdropping)

Evil twin

[Definition](../definitions/definitions_E.md#evil-twin)

Masquerading

[Definition](../definitions/definitions_M.md#masquerading)

Disassociation attack

[Definition](../definitions/definitions_D.md#disassociation-attack)

Key reinstallation attack (KRACK)

[Definition](../definitions/definitions_K.md#key-reinstallation-attack)

Jamming
 
[Definition](../definitions/definitions_J.md#jamming)
