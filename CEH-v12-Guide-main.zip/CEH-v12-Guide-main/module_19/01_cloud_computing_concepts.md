# Section 01: Cloud Computing Concepts

## Cloud Computing Concepts
Cloud computing

[Definition](../definitions/definitions_C.md#cloud-computing)

Fog computing

[Definition](../definitions/definitions_F.md#fog-computing)

Edge computing

[Definition](../definitions/definitions_E.md#edge-computing)
 
Amazon web services (AWS)

[Definition](../definitions/definitions_A.md#amazon-web-services)

Microsoft azure

[Definition](../definitions/definitions_M.md#microsoft-azure)

Google cloud platform (GCP)

[Definition](../definitions/definitions_G.md#google-cloud-platform)
