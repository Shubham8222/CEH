# Section 03: Serverless Computing

## Serverless
Serverless

[Definition](../definitions/definitions_S.md#serverless)

Azure function

[Definition](../definitions/definitions_M.md#azure-function)
