# Module 19: Cloud Computing

## About

According to the official C|EH brochure this module covers the following material.

> Learn different cloud computing concepts, such as container technologies
and server less computing, various cloud computing threats, attacks,
hacking methodology, and cloud security techniques and tools.
