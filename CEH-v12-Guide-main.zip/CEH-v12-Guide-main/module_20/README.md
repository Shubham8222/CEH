# Module 20: Cryptography

## About

According to the official C|EH brochure this module covers the following material.

> Learn about encryption algorithms, cryptography tools, Public Key
Infrastructure (PKI), email encryption, disk encryption, cryptography
attacks, and cryptanalysis tools.
